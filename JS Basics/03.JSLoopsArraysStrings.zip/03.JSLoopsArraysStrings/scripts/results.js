function onPrintButtonClick(result){
document.getElementById('result').innerHTML = result;
}