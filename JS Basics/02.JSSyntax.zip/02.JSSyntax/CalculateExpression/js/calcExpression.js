function calcExpression() {
    document.getElementById('result').innerHTML = eval(document.getElementById('expression').value);
}