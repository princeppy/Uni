<?php
$firstNumber = 3.1415;
$secondNumber = 8.12;
$sum = $firstNumber+$secondNumber;

echo '$firstNumber + $secondNumber' . ' = ' . "$firstNumber + $secondNumber" . ' = ' . number_format($sum,2,'.','');